#include "defs.h"

FILE *altiop = NULL;
FILE *infp = stdin;
FILE *outfile = NULL;
char outname[30];
//char *re_comp(); //
int ecomp();

struct word *wordptr[NWORDS + 1];
struct word *wtord[NWORDS + 1];
float *exptr[PSLICES];
int nwptrs;
int printmin, printmax;
float windowcent = 66 + 12;		/* make float for getval routine */

char wordsound[NWORDS][MAXLEN];
int wordfreq[NWORDS];
struct phoneme phoneme[NPHONS];
struct phoneme *phonptr[128]; /* pointers to phoneme structures indexed 
			   by the character corresponding to the phoneme */

struct feature feature[NCONTINS][NFVALS];

int contlen[NCONTINS] = 
	{NFVALS,NFVALS,NFVALS,NFVALS,NFVALS,NFVALS,NFVALS};

char *phonchar =
	{"pbtdkgsSrlaiu^-"};

char *classchar =
	{"VCLNDGBT"}; /*vocalic, consonantal,liquid,noncompact,dental stop,
			velar stop, bilabial stop, bil/alv  */


char *contname[NCONTINS] = 
{"POW","VOC","DIF","ACU","GRD","VOI","BUR"};

float fweight[NCONTINS] = 
  {1., 1., 1., 1., 1., 1., 1. };

int nwords = 0;

char in[BUFSIZ];

float max = { 1.};
float min = {-.3};
float wbase = {.3};
float wchange = {.1};
float wgain = {1.};
float wramp = {1.};
float rate = {.5};

float ymax = .6;
float ydec = .01;
float pthresh[NLEVS]    = {.00,.00,.05};
float linthresh = .2; 
float linthrsq = .04;
float decay[NLEVS]      = {.01,.03,.05}; 
float alpha[NPARAMS] = 
/*   IF   FF    FP  PP  PW  WW  WP  PF  PFC  */
    {1.0,.00,.020,.00,.05,.00,.03,.00,.00};

float ga[NLEVS] = 
/*   FF    PP     WW */
   {.100, .100, .100};

float rest[NLEVS]   = {-.1, -.1, -.01};

float fscale = {.00};
float imax = {3.};

float psum[PSLICES];
float pisum[PSLICES];
int pcount[PSLICES];

float fsum[NCONTINS][FSLICES];
int fcount[NCONTINS][FSLICES];

float wisum[PSLICES];
float wsum[PSLICES];
int wcount[PSLICES];

float ppi[PSLICES];
float wwi[PSLICES];
float ffi[NCONTINS][FSLICES];
int cycleno;

int nreps = 1;
int sigflag;
int echeck;
int outflag;
int sumflag = 1;
int echoflag = 1;
int grace = 0;
int coartflag = 1;
int printfreq = 3;

int stop();

struct phoneme 	*inphone[MAXITEMS];
char 	inspec[MAXITEMS][60];
float 	infet[MAXITEMS][NCONTINS][NFVALS];

float 	instrength[MAXITEMS];
int 	inpeak[MAXITEMS];
int  	indur[MAXITEMS];
float	inrate[MAXITEMS];
float	insus[MAXITEMS];

struct word 	*outword[MAXITEMS];
struct phoneme 	*outphoneme[MAXITEMS];

int ninputs, nwouts, npouts;

float input[FSLICES][NCONTINS][NFVALS];

main(argc,argv)
int argc; char **argv;
{
	int specflag = 0;
	while (--argc > 0 && (*++argv) [0] == '-') {
		switch (argv[0][1]) {
			case 'p':
				load(*++argv);
				argc--;
				break;
			case 'l':
				lexicon(*++argv);
				argc--;
				break;
			case 'i':
				inspecs(*++argv);
				specflag = 1;
				argc--;
				break;
			case 'f':
				infeats(*++argv);
				argc--;
				break;
			case 'a':	/* to make it easy for sdb */
				abort();
				break;
		}
	}
	initialize();
	if (specflag) inputcomp();
	if (signal(2,stop) & 01) signal(2,stop);
	command();
}

cycle() 
{
	int tick,pmin,pmax;
	for (tick = 0; tick < nreps; tick++) {
	    act_features();
	    fpinteract();
	    ppinteract();
	    pfinteract();
	    pwinteract();
	    wpinteract();
	    wwinteract();
	    fupdate();
	    pupdate();
	    wupdate();
	    cycleno++;
	    if ( !(cycleno%printfreq) ) {
			if (sumflag) {
				if (cycleno>windowcent) {
					printmin  = 6;
					printmax += 66+6;
				}
				summarypr(printmin,printmax,FPP,stdout);
				if (outfile) {
				    summarypr(printmin,printmax,FPP,outfile);
				}
			}
	    }
	    if (sigflag) {sigflag = 0;break;}
	}
}

zarrays() 
{
	WORD *wp, **wptr;
	PHONEME *pp;
	register int i,f,c;

	cycleno = 0;
	printmin = 0;
	printmax = 66;
	
	//extern float infet[MAXITEMS][NCONTINS][NFVALS];
	//extern float input[FSLICES][NCONTINS][NFVALS];
	
	for (i = 0; i < MAXITEMS; i++) {
	    for (c = 0; c < NCONTINS; c++) {
			for(f = 0; f < NFVALS; f++){
				infet[i][c][f] = 0;
			}
		}   
	}
	
	for (i = 0; i < PSLICES; i++) {
		wwi[i] =0; wsum[i] =0; wisum[i] =0; wcount[i] = 0;
		ppi[i] =0; psum[i] =0; pisum[i] = 0; pcount[i] = 0;
	}

	for (i = 0; i < FSLICES; i++) {
	    for (c = 0; c < NCONTINS; c++) {
		ffi[c][i] =0; fsum[c][i] =0; fcount[c][i] = 0;
			for(f = 0; f < NFVALS; f++){
				input[i][c][f] = rest[F];
			}
	}   }

	for ALLWORDPTRS {
	    wp = *wptr;
		wp->pextot = 0;
	    wp->rest = wp->prime + wp->base;
	    for (i = 0; i < PSLICES; i++) {
		wp->ex[i] = wp->rest;
		wp->nex[i] =0;
		wp->pex[i] = 0;
		wp->wex[i] = 0;
	}   }

	for ALLPHONEMES {
		pp->fextot = 0;
		pp->wextot= 0;
	    for (i = 0; i < PSLICES; i++) {
		pp->ex[i] = rest[P];
		pp->wex[i] = 0; pp->fex[i] = 0; pp->nex[i] = 0;
		pp->pex[i] = 0;
	}   }

	for (c = 0; c < NCONTINS; c++) {
	    for (f=0; f < NFVALS; f++) {
		feature[c][f].pextot = 0;
		for (i = 0; i < FSLICES; i++) {
		    feature[c][f].ex[i] = rest[F];
		    feature[c][f].pex[i] = 0;
		    feature[c][f].fex[i] = 0;
		    feature[c][f].nex[i] = 0;
	}   }   }
}

void fullSimulation()
{
	int i,num;
	FILE *file;
	char filename[100], otherfile[100];
	num=80;
	nreps=1;
	
	for(i=0;i<num;i++){
		cycle();
		dumpMatrix();			
	}
	dumpParam();	
}

void simulateLexicon(){
	WORD *wp, **wptr;
	for ALLWORDPTRS{
		lexicon("l.1/slex");
		initialize();
		wp = *wptr;
		test(wp->sound);
		fullSimulation();
	}
	
}

void dumpMatrix()
{
int c,f,slice, phon, wd, i;
	FILE *file;
	char modelInput[20];
	char filename[100], otherfile[100];
	//printf("Filename:");
	//scanf("%s",filename);
	//sprintf(otherfile, "%s.phon",filename);
	for(i = 0; i < MAXITEMS-1; i++){
		if(inspec[i][0]=='.') break;
		else modelInput[i]=inspec[i][0];
	}
	sprintf(filename,"data/%s/input_%.3d.xml", modelInput,(cycleno-1));	
	//sprintf(filename,"data/input_%.3d.xml", (cycleno-1));	
	file = fopen(filename,"w");
	if(file == NULL)
	{
		printf("Could not open file! \n");
		return;
	}
	fprintf(file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n<inputData slice=\"%.3d\" \n\txmlns=\'http://xml.netbeans.org/examples/targetNS\'\n\t\txmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\'\n\txsi:schemaLocation=\'http://xml.netbeans.org/examples/targetNS http://maglab.psy.uconn.edu/jtraceschema.xsd\'>\n", (cycleno-1));
	for ( c = 0; c < NCONTINS; c++){	        
		for (f=0; f < NFVALS; f++){	
	    	if(c == 0) fprintf(file, "\n\t\t<row><feat>POW</feat>");	
	    	if(c == 1) fprintf(file, "\n\t\t<row><feat>VOC</feat>");	
	    	if(c == 2) fprintf(file, "\n\t\t<row><feat>DIF</feat>");	
	    	if(c == 3) fprintf(file, "\n\t\t<row><feat>ACU</feat>");	
	    	if(c == 4) fprintf(file, "\n\t\t<row><feat>GRA</feat>");	
	    	if(c == 5) fprintf(file, "\n\t\t<row><feat>VOI</feat>");	
	    	if(c == 6) fprintf(file, "\n\t\t<row><feat>BUR</feat>");		    
		fprintf(file, "<cont>%d</cont>",f);		
		for(slice = 0 ; slice < FSLICES; slice++){
			if(input[slice][c][f]==0){ fprintf(file, "<a>%.1f</a>", input[slice][c][f]); }
			else{ fprintf(file, "<a>%.17f</a>", input[slice][c][f]);}
		}
		fprintf(file,"</row>");		
	    }
	}
	fprintf(file, "\n\t</inputData>\n");
	fclose(file);
	
	sprintf(filename,"data/%s/feature_%.3d.xml", modelInput,(cycleno-1));	
	//sprintf(filename,"data/feature_%.3d.xml", (cycleno-1));	
	file = fopen(filename,"w");	

	fprintf(file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n<featureData slice=\"%.3d\" \n\txmlns=\'http://xml.netbeans.org/examples/targetNS\'\n\t\txmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\'\n\txsi:schemaLocation=\'http://xml.netbeans.org/examples/targetNS http://maglab.psy.uconn.edu/jtraceschema.xsd\'>\n", (cycleno-1));
	
	for ( c = 0; c < NCONTINS; c++){	        
		for (f=0; f < NFVALS; f++){	
	    	if(c == 0) fprintf(file, "\n\t\t<row><feat>POW</feat>");	
	    	if(c == 1) fprintf(file, "\n\t\t<row><feat>VOC</feat>");	
	    	if(c == 2) fprintf(file, "\n\t\t<row><feat>DIF</feat>");	
	    	if(c == 3) fprintf(file, "\n\t\t<row><feat>ACU</feat>");	
	    	if(c == 4) fprintf(file, "\n\t\t<row><feat>GRA</feat>");	
	    	if(c == 5) fprintf(file, "\n\t\t<row><feat>VOI</feat>");	
	    	if(c == 6) fprintf(file, "\n\t\t<row><feat>BUR</feat>");		    
		fprintf(file, "<cont>%d</cont>",f);		
		for(slice = 0 ; slice < FSLICES; slice++){
		    	//fprintf(file, "<act slice=\"%f\"> ", slice);
				//fprintf(file, "<a>%.17f</a>", feature[c][f].ex[slice]);
				if(feature[c][f].ex[slice]==0){ fprintf(file, "<a>%.1f</a>", feature[c][f].ex[slice]); }
				else{ fprintf(file, "<a>%.17f</a>", feature[c][f].ex[slice]);}				
		}
		fprintf(file,"</row>");		
	    }
	}
	fprintf(file, "\n\t</featureData>\n");
	fclose(file);
	
	sprintf(filename,"data/%s/phon_%.3d.xml",modelInput,(cycleno-1));
	//sprintf(filename,"data/phon_%.3d.xml",(cycleno-1));
	file = fopen(filename,"w");
	
	fprintf(file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n<phonemeData slice=\"%.3d\" \n\txmlns=\'http://xml.netbeans.org/examples/targetNS\'\n\t\txmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\'\n\txsi:schemaLocation=\'http://xml.netbeans.org/examples/targetNS http://maglab.psy.uconn.edu/jtraceschema.xsd\'>\n", (cycleno-1));
	for(phon = 0; phon < NPHONS; phon++){
		fprintf(file, "\n\t\t<row><phon>%c</phon> ",phonchar[phon]);			
		for(slice = 0 ; slice < PSLICES; slice++){
			//fprintf(file, "<act slice\"%f\"> ",slice);
			//fprintf(file, "<a>%.3f</a> ",phoneme[phon].ex[slice]);
			if(phoneme[phon].ex[slice]==0){ fprintf(file, "<a>%.1f</a>", phoneme[phon].ex[slice]); }
			else{ fprintf(file, "<a>%.17f</a>", phoneme[phon].ex[slice]);}
		}
		fprintf(file,"</row>");				
	}
	fprintf(file,"\n\t</phonemeData>\n");
	fclose(file);
	
	sprintf(filename,"data/%s/word_%.3d.xml",modelInput,(cycleno-1));
	//sprintf(filename,"data/word_%.3d.xml",(cycleno-1));
	file = fopen(filename,"w");
	fprintf(file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n\n<wordData slice=\"%.3d\" \n\txmlns=\'http://xml.netbeans.org/examples/targetNS\'\n\t\txmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\'\n\txsi:schemaLocation=\'http://xml.netbeans.org/examples/targetNS http://maglab.psy.uconn.edu/jtraceschema.xsd\'>\n", (cycleno-1));
	for(wd = 0; wd < nwords; wd++){
		fprintf(file, "\n\t\t<row><word>%s</word> ",wordptr[wd]->sound);			
		for(slice = 0 ; slice < PSLICES; slice++){
			//fprintf(file, "<act slice=\"%f\"> ",slice);
			//fprintf(file, "<a>%.3f</a> ",wordptr[wd]->ex[slice]);
			if(wordptr[wd]->ex[slice]==0){ fprintf(file, "<a>%.1f</a>", wordptr[wd]->ex[slice]); }
			else{ fprintf(file, "<a>%.17f</a>", wordptr[wd]->ex[slice]);}
		}
		fprintf(file, "</row>");		
	}
	fprintf(file,"\n\t</wordData>\n");
	fclose(file);	
	//printf("nwords %d \n",nwords);
	printf("ok\n");	
}

void diagnostic2()
{
	int i, j, k;
	double result;
	result = 1.;
	for(i = 1; i < 10000000;){
		result = result * i;
		i += 2;
		if(i>9998000){
		  printf("%.17f\n",result);
		}
		result = result / i;
		i += 3;
		if(i>9998000){
		  printf("%.17f\n",result);
		}
	}

}


void diagnostic()
{
	double a, b, c, d , e ;
	double result;
	int i, j, k;
	result = 1.;
	a=1.; b=1.; c=2.; d=c/(a+b);
	for(i = 1; i < 1000;i++){
		a=b;
		b=c;
		c=d;
		d=c/(a+b);
		//if(i%100==0){
		  printf("%.17f\n",d);
		//}
		
	}

}

void dumpParam()
{	
	int i,wd;
	FILE *file;
	char filename[100], modelInput[20];
	//printf("Filename:");
	//scanf("%s",filename);
	//sprintf(otherfile, "%s.phon",filename);
	for(i = 0; i < MAXITEMS-1; i++){
		if(inspec[i][0]=='.') break;
		modelInput[i]=inspec[i][0];
	}
	sprintf(filename,"data/%s/parameters.jt", modelInput,(cycleno-1));	
	//sprintf(filename,"data/parameters.xml");	
	file = fopen(filename,"w");
	if(file == NULL)
	{
		printf("Could not open file! \n");
		return;
	}
	fprintf(file, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<jt xmlns=\'http://xml.netbeans.org/examples/targetNS\' \n\txmlns:xsi=\'http://www.w3.org/2001/XMLSchema-instance\' xsi:schemaLocation=\'http://xml.netbeans.org/examples/targetNS http://maglab.psy.uconn.edu/jtraceschema.xsd\'>\n\t<description>cTRACE simulation parameters</description>\n\t<script>\n\t\t<action>\n\t\t<set-parameters><parameters>");
	fprintf(file, "\n\t\t<StringParam><name>comment</name><StringValue>parameters from a cTrace simulation.</StringValue></StringParam>");
	fprintf(file, "\n\t\t<DecimalParam><name>alpha.if</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", alpha[IF]);
	fprintf(file, "\n\t\t<DecimalParam><name>alpha.fp</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", alpha[FP]);
	fprintf(file, "\n\t\t<DecimalParam><name>alpha.pw</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", alpha[PW]);
	fprintf(file, "\n\t\t<DecimalParam><name>alpha.pf</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", alpha[PF]);
	fprintf(file, "\n\t\t<DecimalParam><name>alpha.wp</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", alpha[WP]);
	fprintf(file, "\n\t\t<DecimalParam><name>decay.f</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", decay[F]);
	fprintf(file, "\n\t\t<DecimalParam><name>decay.p</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", decay[P]);
	fprintf(file, "\n\t\t<DecimalParam><name>decay.w</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", decay[W]);
	fprintf(file, "\n\t\t<DecimalParam><name>gamma.f</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", ga[F]);
	fprintf(file, "\n\t\t<DecimalParam><name>gamma.p</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", ga[P]);
	fprintf(file, "\n\t\t<DecimalParam><name>gamma.w</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", ga[W]);
	fprintf(file, "\n\t\t<DecimalParam><name>rest.f</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", rest[0]);	
	fprintf(file, "\n\t\t<DecimalParam><name>rest.p</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", rest[1]);	
	fprintf(file, "\n\t\t<DecimalParam><name>rest.w</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", rest[2]);	
	fprintf(file, "\n\t\t<DecimalParam><name>min</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", min);
	fprintf(file, "\n\t\t<DecimalParam><name>max</name><DecimalValue>%.3f</DecimalValue></DecimalParam>", max);
	fprintf(file, "\n\t\t<IntParam><name>fSlices</name><IntValue>%d</IntValue></IntParam>", FSLICES);
	fprintf(file, "\n\t\t<IntParam><name>nwords</name><IntValue>%d</IntValue></IntParam>", nwords);
	fprintf(file, "\n\t\t<IntParam><name>nreps</name><IntValue>%d</IntValue></IntParam>", nreps);
	fprintf(file, "\n\t\t<IntParam><name>slicesPerPhon</name><IntValue>%d</IntValue></IntParam>", FPP);	
	for(i = 0; i < MAXITEMS-1; i++){
		modelInput[i]=inspec[i][0];
	}
	fprintf(file, "\n\t\t<StringParam><name>modelInput</name><StringValue>%s</StringValue></StringParam>", modelInput);
	fprintf(file, "\n\t\t<StringParam><name>phonContinuum</name><StringValue>pb3</StringValue></StringParam>");
	//fprintf(file, "\n\t\t<IntParam><name>deltaSlices</name><IntValue>%d</IntValue></IntParam>", );
	fprintf(file, "\n\t\t<lexicon>");
	for(wd = 0; wd < nwords;wd++){ 	
		fprintf(file, "\n\t\t\t<lexeme><phonology>%s</phonology></lexeme>", wordptr[wd]->sound);
	}
	fprintf(file, "\n\t\t</lexicon>");
	fprintf(file, "\n\t\t<IntParamRep><name>FETSPREAD</name>");
	for(i = 0;i < NCONTINS; i++){
		fprintf(file, "\n\t\t\t<IntValue>%d</IntValue>", fetspread[i]);
	}
	fprintf(file, "\n\t\t</IntParamRep>");
	
	fprintf(file, "\n\t\t<DecimalParamRep><name>spreadScale</name>");
	for(i = 0;i < NCONTINS; i++){
		fprintf(file, "\n\t\t\t<DecimalValue>1.0</DecimalValue>");
	}
	fprintf(file, "\n\t\t</DecimalParamRep>");
	fprintf(file, "\n\t</parameters>\n\t</set-parameters></action>");	
	fprintf(file, "\n\t<action><set-cycles-per-sim><cycles>80</cycles></set-cycles-per-sim></action>");
	fprintf(file, "\n\t<action><new-window><arg>n/a</arg></new-window></action>");
	fprintf(file, "\n\t</script></jt>");
	fclose(file);	
	printf("ok\n");	
}
